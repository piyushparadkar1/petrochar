# Riazi MNL50 Reference Data

This folder contains numerical data tables transcribed from:

> Riazi, M. R. (2005). *Characterization and Properties of Petroleum Fractions*. ASTM Manual MNL50. ASTM International, West Conshohocken, PA. ISBN 0-8031-3361-8.

These tables are reproduced here strictly for **software validation purposes** — to enable automated regression tests that confirm petrochar reproduces the textbook's worked examples to within published tolerances.

## Files

- `table_4_6_scn_groups.csv` — Physical properties of SCN groups C6 to C50 (M, Tb, SG, n20, d20, Tc, Pc, dc, Zc, omega, sigma, delta). From Riazi MNL50 Table 4.6, page 162.
- `table_4_11_example_4_7.csv` — North Sea gas condensate C7+ fraction sample data, 12 fractions. From Riazi MNL50 Table 4.11, page 171.
- `table_4_13_distribution_coeffs.csv` — Distribution coefficients of Eq. (4.56) for M, Tb, SG fitted to Table 4.11 data. Both three-parameter and two-parameter fits. From Riazi MNL50 Table 4.13, page 173.
- `table_4_21_quadrature_points.csv` — Gauss-Laguerre quadrature points/weights for 3- and 5-point integration. Used in Riazi Eq. (4.96). From Riazi MNL50 Table 4.21, page 186.
- `table_4_22_quadrature_3pt_example_4_14.csv` — 3-point Gaussian quadrature output for Example 4.14 (gamma model on the C7+ system). From Riazi MNL50 Table 4.22, page 186.
- `table_4_23_lumping_example_4_15.csv` — 5-component lumping for Example 4.15 (North Sea oil), Method I (Gaussian quadrature) and Method II (carbon-number-range). From Riazi MNL50 Table 4.23, page 187.

## CSV format conventions

Each CSV begins with one or more comment rows starting `#` documenting source citation, table number, page, and any narrative notes from the textbook needed to interpret the values.

Column names include explicit units in parentheses or as suffixes: e.g. `M_g_per_mol`, `Tb_K`, `SG_dimensionless`, `pct_AAD`.

Empty cells correspond to "—" in the source (typically when a property is not reported for a given row, e.g. `Tb_K` for the C18+ residue in Table 4.11).

No proprietary data, no plant data, no client-specific information appears in any file in this folder.

## Usage in tests

The `tests/test_phase*` modules load these CSVs to obtain reference inputs and expected outputs for pass-gate validation. Test tolerances follow Riazi MNL50 conventions:

- Tb prediction: ±2 K typical, ±5 K worst case
- M prediction: ±1.5% typical
- SG prediction: ±0.005 typical (or ±0.5%)
- Distribution coefficients (P_o, A, B): ±5%
- Mixture average properties: ±1%

## Important interpretation notes

1. **Table 4.13 has both 3-param and 2-param fits.** Phase 3's pass-gate test compares against the **three-parameter** row for Tb (P_o=350, A=0.1679, B=1.2586). The two-parameter rows are for sensitivity testing only.

2. **Table 4.22 uses the gamma model, not the generalized model.** Riazi Example 4.14 applies 3-point Gaussian quadrature to a *gamma* distribution with α=1 (which reduces to exponential), eta=90, beta=28.9. The petrochar tool's *primary* path uses the generalized model (Eq. 4.56), so this table validates the gamma path (legacy/optional support); a separate test for the generalized-model path uses the parameters from Table 4.13.

3. **Table 4.23 mixture properties are the validation target.** The individual M_i and SG_i for components from Method I and Method II differ between methods (different lumping conventions). What matters is that mixture-level averages match: M_av ≈ 152.5 vs experimental 151.6, SG_av ≈ 0.7905 vs experimental 0.7917. Tolerance ±1.5% on M and ±0.5% on SG.

4. **Table 4.6 data for Tc, Pc, dc, Zc, omega, sigma, delta are derived from correlations**, not direct measurements, per Riazi's footnote. Phase 1 tests should validate against (M, Tb, SG, n20, d20) only; the derived properties are useful for cross-checks in later phases but are not Phase 1 pass-gates.
