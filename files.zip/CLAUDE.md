# CLAUDE.md — petrochar project rules

## Read this at the start of every Claude Code session.

This file is the project-specific equivalent of `~/.claude/CLAUDE.md`. It establishes rules and design decisions that apply to all sessions on this repository.

For full context, also read `CLAUDE_CODE_PROMPT.md` (the original Session 0 brief — authoritative on Phase 0 scope and architecture commitments) and `CURRENT_STATUS.md` (the running session log).

---

## STRICT BOUNDARIES

### 1. Repository isolation — DO NOT READ OUTSIDE THIS REPO

You are forbidden from reading any file outside this repository's root. There is an older sibling project (paths like `~/projects/pda_pcsaft_tool/` or similar) with a different architecture (a 7-component "L/H" framework) that this project deliberately moves away from. Reading it would corrupt your design decisions through pattern-matching.

Concretely:
- Do NOT `view`, `cat`, `grep`, `find`, or `ls` paths outside this repo's root.
- Do NOT use `bash_tool` to navigate via `cd ..` to read sibling files.
- Do NOT search the filesystem for similarly-named projects.

Verification before any commit (all must return zero hits):
```bash
grep -rn "import" --include="*.py" . | grep -vE "^[^:]*:[^:]*:(from |import )(numpy|scipy|pandas|matplotlib|pytest|streamlit|openpyxl|core|tabs|tests|os|sys|json|pathlib|typing|dataclasses|warnings|math|csv|io|abc|functools)"
grep -rni "pda_pcsaft\|paradkar\|pda.pcsaft\|extractor_parameters\|sara_analysis" . --include="*.py" --include="*.md" --exclude-dir=.git
grep -rni "HPCL\|KBR\|Mumbai\|Plant 41\|BIDEP" . --include="*.py" --include="*.md" --include="*.csv" --exclude-dir=.git
```

### 2. Concept-naming discipline — DO NOT USE OLD-FRAMEWORK TERMS

Forbidden anywhere in this repository:
- `MW_ARO_L`, `MW_ARO_H`, `MW_RES_L`, `MW_RES_H`, or any `_L`/`_H` suffixed variants
- "harmonic mean MW closure"
- "L/H split", "split fraction", "redistribution solver"
- "calibration knob", "tuning parameter for MW"
- "DAO SARA", "DAO yield target"

If you find yourself reaching for one of these, stop. The architecture in petrochar does not have them.

### 3. Primary sources only

Acceptable references:
- Riazi, M. R. (2005). MNL50, Chapter 4. Reference data in `data/riazi_reference/`.
- Panuganti et al. (2012). *Fuel*, 93, 658.
- Gonzalez et al. (2007). *Energy & Fuels*, 21, 1230.
- Watson and Nelson (1933). *Ind. Eng. Chem.*, 25, 880.
- Whitson (1983). *SPE Journal*, 23(4), 683.
- García Cárdenas and Ancheyta (2022). *Ind. Eng. Chem. Res.*, 61, 3383.

### 4. No DAO data, no process-side data, ever

Feed-side characterization only. No DAO inputs/outputs/references in code, comments, docstrings, variables. No "yield", "extractor", "stage" concepts.

### 5. No phase-equilibrium computation

No flashes, no LLE solvers, no chemical-potential equality root-finding.

### 6. No tuning against process observables

Pseudo-component properties come from feed measurements and published correlations only.

---

## DEVELOPMENT PROTOCOL

1. **No shortcuts. No stubs.** Every function fully implemented.
2. **Validation-first.** Each phase reproduces a Riazi textbook example to within stated tolerance before proceeding. **Pass-gates are non-negotiable.**
3. **Citation density.** Every correlation cites Riazi MNL50 page/equation, Panuganti section, Gonzalez section.
4. **Units explicit, always.** Function signatures document units. Tb in K internally.
5. **No proprietary names anywhere.** Generic only.
6. **Session protocol.**
   - Start: read `CURRENT_STATUS.md`. Read only files needed for current phase.
   - End: update `CURRENT_STATUS.md` with phase completion, decisions, blockers, session entry. Commit.

---

## ARCHITECTURE COMMITMENTS

- **Distribution model:** Riazi generalized (Eq. 4.56). Gamma kept as legacy option only — fails on heavy oils per Riazi p. 178-179.
- **Quadrature:** Riazi §4.6.1.1, Table 4.21. 5-point default. 3-point selectable. Values in `data/riazi_reference/table_4_21_quadrature_points.csv`.
- **Asphaltenes:** Always discrete. Gonzalez 2007: m=33, σ=4.3 Å, ε/k=400 K. Tb=800°C and SG=1.15 are conventions.
- **Aromaticity γ:** per-component Watson K via `γ = clamp((13.0 − K_W) / (13.0 − 9.5), 0, 1)`.
- **PC-SAFT parameters:** Panuganti 2012 Table 6 for distillable; Gonzalez 2007 for asphaltenes; propane fixed: m=2.002, **σ=3.6180 Å** [not 3.168, Aspen typo], ε/k=208.11 K.
- **SARA closure:** ASP wt% as hard tail constraint. SAT/ARO/RES as K_W-bin closure check (not constraint, never tuned to).

---

## VERIFICATION BEFORE COMMIT

- Each phase: run all phase pass-gate tests via `pytest`. Do not commit if any test fails.
- Search proprietary terms with `grep -ni` (zero hits required, see above).
- Confirm no `import` statements reference paths outside this repo (zero hits required).
- After Streamlit changes: `python -m py_compile app.py` then `streamlit run app.py` boot test.

---

## WHEN INSTRUCTIONS CONFLICT

- `CLAUDE_CODE_PROMPT.md` wins over this file (it is the original brief).
- This file wins over docstrings or in-code comments.
- User instructions in chat win over this file, but flag the conflict explicitly and propose updating this file or `CLAUDE_CODE_PROMPT.md`.
