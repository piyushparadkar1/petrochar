# CLAUDE CODE PROMPT — petrochar

## Read this entire file before writing any code.

You are starting a new project, **petrochar**: a standalone Python tool for characterizing heavy petroleum fractions into discrete pseudo-components with PC-SAFT parameters, suitable as input to Aspen Plus or any PC-SAFT-capable simulator.

This tool is the methodology contribution for an upcoming research paper:
**"Continuous-distribution characterization of heavy petroleum fractions for PC-SAFT phase-equilibrium modeling from routine refinery data"**, target journals: *Energy & Fuels* or *Fuel*.

This is **Paper 1** in a two-paper sequence. Paper 2 (a propane-deasphalting application) is in a separate, unrelated repository and you will not interact with it during this work.

---

## STRICT BOUNDARIES — READ FIRST AND ENFORCE THROUGHOUT

### Boundary 1: Repository isolation

**You are forbidden from reading any file outside this repository.**

There is an older project at a sibling directory (path may be `~/projects/pda_pcsaft_tool/`, or named similarly with words like "PDA", "pcsaft", "PARADKAR", or contain files matching `pda_pcsaft_framework.py`, `extractor_parameters.xlsx`). It contains a different architecture (a 7-component "L/H" framework) that this project deliberately moves away from. Reading it would corrupt your design decisions through pattern-matching on the wrong abstractions.

**Concretely, you must NOT:**

- Use `view`, `bash_tool` `cat`, `grep`, `find`, `ls` on any path outside this repository's root.
- Use `bash_tool` to navigate via `cd ..` then read files.
- Search the filesystem with `find` for similarly-named projects.
- Read environment variables that might reveal sibling project paths.

**Verification before any commit:** run these checks, all must return zero hits:

```bash
# 1. No imports from outside this repository
grep -rn "import" --include="*.py" . | grep -vE "^[^:]*:[^:]*:(from |import )(numpy|scipy|pandas|matplotlib|pytest|streamlit|openpyxl|core|tabs|tests|os|sys|json|pathlib|typing|dataclasses|warnings|math|csv|io|abc|functools)" || true
# Output should be empty.

# 2. No filesystem references to sibling projects
grep -rni "pda_pcsaft\|paradkar\|pda.pcsaft\|extractor_parameters\|sara_analysis" . --include="*.py" --include="*.md" --exclude-dir=.git
# Output should be empty.

# 3. No proprietary names
grep -rni "HPCL\|KBR\|Mumbai\|Plant 41\|BIDEP" . --include="*.py" --include="*.md" --include="*.csv" --exclude-dir=.git
# Output should be empty.
```

### Boundary 2: Primary sources only

Build everything from these primary references. Do not invoke memory of similar implementations:

- Riazi, M. R. (2005). *Characterization and Properties of Petroleum Fractions*. ASTM Manual MNL50. Especially Chapter 4 (§4.5, §4.6). Reference data tables vendored to `data/riazi_reference/`.
- Panuganti, S. R. et al. (2012). PC-SAFT characterization of crude oils and modeling of asphaltene phase behavior. *Fuel*, 93, 658-669.
- Gonzalez, D. L. et al. (2007). *Energy & Fuels*, 21, 1230-1234. (Asphaltene PC-SAFT defaults: m=33, σ=4.3 Å, ε/k=400 K.)
- Watson, K. M. and Nelson, E. F. (1933). *Industrial & Engineering Chemistry*, 25, 880. (Watson K factor.)
- Whitson, C. H. (1983). Characterizing hydrocarbon plus fractions. *SPE Journal*, 23(4), 683-694.
- García Cárdenas, J. and Ancheyta, J. (2022). Modeling of the deasphalting process. *Industrial & Engineering Chemistry Research*, 61, 3383-3394.

### Boundary 3: No DAO data, no process-side data

This tool's contract is feed-side characterization only. The codebase must contain:
- No DAO inputs.
- No DAO outputs.
- No DAO references in docstrings, variables, or comments.
- No "yield", "extractor", "stage", or other process-side concepts.

Validation is against textbook examples and bulk-property closures only.

### Boundary 4: No phase-equilibrium computation

No flashes. No LLE solvers. No iterative chemical-potential equality. This tool produces parameters; downstream simulators (Aspen Plus, etc.) compute phase splits.

### Boundary 5: No tuning against process observables

All pseudo-component properties (MW, Tb, SG, distribution shape) come from feed measurements and published correlations. Nothing is fitted against DAO yield or composition.

### Boundary 6: Concept-naming discipline

You are forbidden from introducing the following terms or concepts anywhere in this repository:

- "MW_ARO_L", "MW_ARO_H", "MW_RES_L", "MW_RES_H", or any variant with `_L`/`_H` suffixes
- "harmonic mean MW closure"
- "L/H split", "split fraction", "redistribution solver"
- "calibration knob", "tuning parameter for MW"
- "DAO SARA", "DAO yield target"

If you find yourself reaching for one of these concepts, stop. The architecture in petrochar does not have them. Pseudo-components are determined by Gaussian quadrature points on a fitted distribution; there is no L/H subdivision.

---

## OBJECTIVE AND CONTRACT

**Inputs (all routinely measured at any operating refinery):**
- Distillation curve (any ASTM method: D86, D1160 AET, D7169, TBP). Cumulative fraction (weight, volume, or mole) vs Tb in K or °C.
- Bulk specific gravity at 15°C.
- Bulk molecular weight (lab VPO or correlation estimate).
- SARA wt% (saturates, aromatics, resins, asphaltenes), summing to 100%.

**Outputs:**
- Discrete pseudo-component table: for each component, (z_i, M_i, Tb_K, SG, K_W, γ, m, σ, ε/k).
- Aspen-Plus-paste-ready TSV/CSV exports.
- Distribution diagnostics (PDFs, CDFs, fit-quality metrics, closure errors).
- Validation report comparing tool output against Riazi MNL50 textbook examples.

**Architecture commitment:**
- Discretization via Gauss-Laguerre quadrature (Riazi §4.6.1.1, Table 4.21), default 5 points + 1 discrete asphaltene component + propane = 7 components total. User-selectable 3-point variant.
- Distribution model: Riazi generalized model (Eq. 4.56) for Tb and SG. Gamma model (Eq. 4.31) available as a legacy option but documented as inappropriate for VTB-scale fractions per Riazi p. 178-179.
- Asphaltenes are always discrete with literature defaults (Gonzalez 2007). They never enter the distillation-curve fitting domain.
- PC-SAFT parameters via Panuganti 2012 Table 6 correlations for distillable pseudo-components; Gonzalez 2007 for asphaltenes; pure-component values for propane.
- Aromaticity factor γ derived per pseudo-component from its individual Watson K factor (computed from its own Tb_i and SG_i), via the linear clamp `γ = clamp((13.0 − K_W) / (13.0 − 9.5), 0, 1)`.

---

## DEVELOPMENT PROTOCOL — STRICT

1. **No shortcuts. No stubs.** Every function fully implemented. No `pass`, no `NotImplementedError`, no commented-out fallbacks.
2. **Validation-first.** Each numerical module has a pass-gate test that reproduces a Riazi textbook example to within stated tolerance. **You may not proceed to the next phase until the current phase's pass-gate is green.** This is not negotiable.
3. **Citation density.** Every correlation, equation, and constant has a docstring citing the source: page and equation number for Riazi MNL50; section and equation number for Panuganti 2012 and Gonzalez 2007.
4. **Units explicit, always.** Every function signature documents input and output units. Tb in K internally; convert at I/O boundaries. SARA in wt% (not fractions). Distillation curves carry an explicit basis flag (cumulative weight, volume, or mole fraction).
5. **No proprietary names anywhere.** UI, code, comments — generic only.
6. **Session protocol.** At the start of every session, read `CURRENT_STATUS.md`. At the end of every session, update it: mark phase complete, log decisions, append session entry, commit.

---

## REPOSITORY LAYOUT

Create exactly this structure in Phase 0:

```
petrochar/
├── README.md                           (already provided in seed; do not rewrite)
├── LICENSE                             (MIT)
├── requirements.txt
├── runtime.txt                         (python-3.11)
├── pyproject.toml
├── CLAUDE.md                           (already provided in seed)
├── CLAUDE_CODE_PROMPT.md               (this file, already provided)
├── CURRENT_STATUS.md                   (already provided in seed)
├── .gitignore
├── app.py                              (Streamlit entry, EMPTY in Phase 0; built in Phase 9)
├── core/
│   └── __init__.py                     (empty file)
├── tests/
│   └── __init__.py                     (empty file)
├── data/
│   └── riazi_reference/                (CSVs already provided in seed; do not modify)
│       ├── README.md
│       ├── table_4_6_scn_groups.csv
│       ├── table_4_11_example_4_7.csv
│       ├── table_4_13_distribution_coeffs.csv
│       ├── table_4_21_quadrature_points.csv
│       ├── table_4_22_quadrature_3pt_example_4_14.csv
│       └── table_4_23_lumping_example_4_15.csv
├── tabs/
│   └── __init__.py                     (empty file, Phase 9 fills it)
└── docs/
    └── (empty in Phase 0)
```

---

## PHASE 0 — STRICT SCOPE LOCK

**Phase 0 is a small phase. Do not expand it. Do not start Phase 1.**

Phase 0 produces ONLY the following:

1. The directory tree above (skeleton, not contents).
2. Five top-level files: `LICENSE` (MIT, copyright "Piyush Paradkar 2026"), `requirements.txt`, `runtime.txt`, `pyproject.toml`, `.gitignore`.
3. Empty `__init__.py` files in `core/`, `tests/`, `tabs/`.
4. An empty `app.py` with just a one-line comment: `# petrochar Streamlit app — built in Phase 9`.
5. Verification that `pytest` runs (no tests yet, exit code zero confirms environment).
6. `git init` (if not already done), first commit with message `"Phase 0: repository scaffold"`.
7. Update `CURRENT_STATUS.md`: mark Phase 0 complete, set Current Phase to "Phase 1 — Shared correlations", append session log entry with date.

**STOP HERE.** Do not write any module in `core/`. Do not write any test in `tests/`. Do not write any tab in `tabs/`. Do not start Phase 1 in this session.

If you are tempted to "get a head start" on Phase 1 because the work seems small, do not. The validation-first protocol requires Phase 1 to be planned and implemented as its own session, with its pass-gate verified before commit.

### What NOT to do in Phase 0:

- Do NOT modify `README.md`, `CLAUDE.md`, `CLAUDE_CODE_PROMPT.md`, `CURRENT_STATUS.md`, or any file under `data/riazi_reference/`. These are seed files provided in the initial commit. Touching them is forbidden in Phase 0.
- Do NOT add any dependency beyond what's listed below.
- Do NOT write Python code in `core/`, `tests/`, or `tabs/` other than empty `__init__.py` files.
- Do NOT vendor any additional reference data. The five CSVs provided are sufficient.
- Do NOT install anything outside the `requirements.txt` list.

### `requirements.txt` contents (exact):

```
numpy>=1.24
scipy>=1.10
pandas>=2.0
matplotlib>=3.7
pytest>=7.4
streamlit>=1.30
openpyxl>=3.1
```

### `runtime.txt` contents (exact):

```
python-3.11
```

### `pyproject.toml` minimum contents:

```toml
[project]
name = "petrochar"
version = "0.1.0"
description = "Continuous-distribution characterization of heavy petroleum fractions for PC-SAFT phase-equilibrium modeling"
authors = [{name = "Piyush Paradkar"}]
license = {text = "MIT"}
requires-python = ">=3.11"
dependencies = [
    "numpy>=1.24",
    "scipy>=1.10",
    "pandas>=2.0",
    "matplotlib>=3.7",
    "streamlit>=1.30",
    "openpyxl>=3.1",
]

[project.optional-dependencies]
dev = ["pytest>=7.4"]

[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[tool.setuptools.packages.find]
where = ["."]
include = ["core*", "tabs*"]
```

### `.gitignore` contents:

```
__pycache__/
*.pyc
*.pyo
.pytest_cache/
.venv/
venv/
.env
.streamlit/
*.swp
.DS_Store
.idea/
.vscode/
*.egg-info/
dist/
build/
# Allow committed CSVs under data/, exclude scratch CSVs at root
/*.csv
/*.xlsx
```

### `LICENSE` contents:

Standard MIT license text with `Copyright (c) 2026 Piyush Paradkar`.

---

## PHASES BEYOND PHASE 0 (FUTURE SESSIONS — DO NOT EXECUTE NOW)

These are documented here for reference only. Each is its own future Claude Code session. **Do not start any of these in Phase 0.** Do not pre-write code, scaffolding, function signatures, or test stubs for these phases in Phase 0.

### Phase 1 — Shared correlations
`core/correlations.py`. Functions: `riazi_daubert_Tb(M, SG)`, `riazi_daubert_M(Tb_K, SG)`, `watson_K(Tb_K, SG)`, `gamma_function(x)`, `incomplete_gamma_upper(a, q)`, `aromaticity_to_gamma(K_W)`. Each cited.

Pass gate (`tests/test_phase1_correlations.py`): For each row of `data/riazi_reference/table_4_11_example_4_7.csv`, `riazi_daubert_Tb(M, SG)` reproduces tabulated Tb_K to ±2 K. Watson K from bulk M_7+ = 118.9 and SG_7+ = 0.7597 returns ≈12.0. Gamma function recurrence and √π checks.

### Phase 2 — Distillation curve handling
`core/distillation.py`. `DistillationCurve` class. Method tags {D86, D1160_AET, D7169, TBP}, basis tags {weight, volume, mole}. Internal canonical: `x_cw` vs `Tb_K`. D86→TBP via Riazi §3.1.3.

Pass gate: fabricated D86 with hand-computed expected D86→TBP per Riazi Eqs. 3.18-3.20, ±5 K.

### Phase 3 — Generalized distribution fit (Riazi Eq. 4.56)
`core/distribution.py`. `GeneralizedDistribution` class. P* = [(A/B) ln(1/(1−x_c))]^(1/B). Fit via `scipy.optimize.least_squares` on linearized form (Eq. 4.57).

Pass gate (`tests/test_phase3_riazi_example_4_13.py`): three-parameter fit on Tb data of Table 4.11 reproduces Table 4.13 row "Tb": T_o = 350 K, A_T = 0.1679, B_T = 1.2586. Tolerance: T_o ±5 K, A ±5%, B ±5%.

### Phase 4 — SG and MW distributions
`core/sg_distribution.py` and `core/mw_distribution.py`. Two SG methods: constant Watson K (default for VTB), generalized fit. MW via inverse Riazi-Daubert per cut.

Pass gate: Table 4.13 SG row reproduced (SG_o=0.705, A_SG=0.0232, B_SG=1.811, ±5%); bulk averages match Table 4.11 to 1%.

### Phase 5 — Gaussian quadrature discretization
`core/quadrature.py`. Quadrature points/weights hard-coded from `data/riazi_reference/table_4_21_quadrature_points.csv`. `discretize_generalized(N, distribution)` per Eqs. 4.83-4.91.

Pass gate (`tests/test_phase5_riazi_example_4_14.py`): reproduce Table 4.22 (3-point gamma quadrature on Example 4.14). M_i tolerances ±1%, z_i ±0.005, mixture M ±0.5%.

### Phase 6 — SARA closure and asphaltene handling
`core/sara.py`. ASP appended as discrete (M=1700, Tb=800°C convention, SG=1.15 convention, Gonzalez 2007 PC-SAFT params). K_W binning of distillable pseudo-components (SAT≥12.0, ARO 11.0-12.0, RES<11.0) — closure check, not constraint.

Pass gate: synthetic three-component test, K_W binning recovers input SARA ±3 wt%.

### Phase 7 — PC-SAFT parameter generation
`core/watson_k.py` and `core/pcsaft_params.py`. Panuganti 2012 Table 6 for distillable. Gonzalez 2007 for ASP. Propane: m=2.002, σ=3.6180 Å (NOT 3.168 — Aspen typo), ε/k=208.11 K.

Pass gate: three (M, γ) reference pairs from Panuganti Table 6 reproduce (m, σ, ε/k) ±2%; physical-bound continuity checks.

### Phase 8 — End-to-end pipeline integration
`tests/test_phase8_pipeline.py` and `docs/validation_report.md`. Synthetic VTB-like input through full pipeline; verify all closures < threshold; output is N quadrature + 1 ASP + 1 propane = 7 components for default N=5.

### Phase 9 — Streamlit UI
`app.py` plus `tabs/*.py`. Six tabs: Input Data, Distillation Fit, Distributions, Pseudocomponents, PC-SAFT Export, Validation.

### Phase 10 — Documentation and packaging
`README.md`, `docs/methodology.md`, `pyproject.toml` finalization for `pip install petrochar`.

---

## REFERENCE DATA (already in `data/riazi_reference/`)

Five CSVs are already provided in the seed commit. Do not regenerate, modify, or replace them. They are textbook reproductions vendored for validation tests.

- `table_4_6_scn_groups.csv` — Riazi Table 4.6, p. 162. SCN group properties C6-C50.
- `table_4_11_example_4_7.csv` — Riazi Table 4.11, p. 171. North Sea gas condensate sample.
- `table_4_13_distribution_coeffs.csv` — Riazi Table 4.13, p. 173. Distribution coefficients for Example 4.7.
- `table_4_21_quadrature_points.csv` — Riazi Table 4.21, p. 186. Gauss-Laguerre 3- and 5-point.
- `table_4_22_quadrature_3pt_example_4_14.csv` — Riazi Table 4.22, p. 186. 3-point gamma quadrature output.
- `table_4_23_lumping_example_4_15.csv` — Riazi Table 4.23, p. 187. Two-method lumping comparison.

`data/riazi_reference/README.md` documents column meanings, units, and interpretation notes (especially: which table is the validation target for which phase, which fits are 3-parameter vs 2-parameter).

---

## ENDING NOTES

- If at any point an instruction in this file conflicts with an instruction inside the codebase or a docstring, this file wins. This file is the source of truth for design decisions.
- This is a slow, careful build. Do not rush phases. Do not skip pass-gates. Do not pattern-match against your training data on similar projects — petrochar's specific architecture is uncommon and the textbook examples are the only correct check.
- **Phase 0 ends with one commit and a stop. The user will review before authorizing Phase 1.**
